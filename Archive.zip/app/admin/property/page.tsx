"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { Tab } from "@headlessui/react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/components/AuthProvider";
import AuthenticatedLayout from "@/components/AuthenticatedLayout";
import PermissionGate from "@/components/PermissionGate";
import { toast } from "react-hot-toast";
import Image from "next/image";
import {
  Building2,
  MapPin,
  Check,
  X,
  Upload,
  Plus,
  Save,
  Wifi,
  Car,
  Shield,
  Info,
} from "lucide-react";
import { getPropertyById, updateProperty } from "@/lib/propertyService";

// Define property type for form data
interface PropertyFormData {
  name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  max_occupancy: number;
  description: string;
  // Location data
  latitude: number | null;
  longitude: number | null;
  neighborhood_description: string;
  // Property details
  wifi_name: string;
  wifi_password: string;
  check_in_instructions: string;
  check_out_instructions: string;
  house_rules: string;
  security_info: string;
  parking_info: string;
  // Amenities (stored as array or JSON)
  amenities: string[];
  // Add this line to include main_photo_url
  main_photo_url?: string;
}

export default function PropertySettings() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [property, setProperty] = useState<any>(null);
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);
  const [propertyId, setPropertyId] = useState<string | null>(null);

  // Add section-specific saving states
  const [isSavingBasic, setIsSavingBasic] = useState(false);
  const [isSavingDetails, setIsSavingDetails] = useState(false);
  const [isSavingLocation, setIsSavingLocation] = useState(false);

  // React Hook Form setup
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<PropertyFormData>();

  // Property types for dropdown
  const propertyTypes = [
    "House",
    "Apartment",
    "Condo",
    "Cabin",
    "Villa",
    "Townhouse",
    "Other",
  ];

  // Common amenities for checkbox selection
  const commonAmenities = [
    "Wi-Fi",
    "Kitchen",
    "Washer",
    "Dryer",
    "Air conditioning",
    "Heating",
    "TV",
    "Pool",
    "Hot tub",
    "Patio",
    "BBQ grill",
    "Fireplace",
    "Cable TV",
    "Free parking",
    "Gym",
    "Workspace",
    "Smoke detector",
    "First aid kit",
  ];

  // Fetch property data
  useEffect(() => {
    async function loadProperty() {
      try {
        let propertyData;

        // If propertyId is provided, use that, otherwise get main property
        if (propertyId) {
          propertyData = await getPropertyById(propertyId);
        } else {
          // Assuming you store the property ID in some state or context
          const { data } = await supabase
            .from("properties")
            .select("id")
            .limit(1)
            .single();

          if (data) {
            propertyData = await getPropertyById(data.id);
          }
        }

        if (propertyData) {
          setProperty(propertyData);
          // Also set the propertyId if it wasn't set already
          if (!propertyId && propertyData.id) {
            setPropertyId(propertyData.id);
          }
          // Populate form with property data
          reset(propertyData);
        }
      } catch (error) {
        console.error("Error loading property:", error);
        toast.error("Failed to load property data");
      }
    }

    loadProperty();
  }, [propertyId, reset]);

  // Handle form submission
  const onSubmit = async (data: PropertyFormData) => {
    if (!user) return;

    try {
      setIsSaving(true);

      // Format data if needed
      const formattedData = {
        ...data,
        updated_at: new Date().toISOString(),
      };

      let result;

      // Update or insert based on whether we have an existing property
      if (property?.id) {
        result = await supabase
          .from("properties")
          .update(formattedData)
          .eq("id", property.id);
      } else {
        result = await supabase
          .from("properties")
          .insert([formattedData])
          .select();
      }

      if (result.error) {
        throw result.error;
      }

      toast.success("Property settings saved successfully");

      // Update local state
      if (result.data) {
        setProperty(result.data[0] || result.data);
      }
    } catch (error: any) {
      console.error("Error saving property:", error);
      toast.error(error.message || "Failed to save property settings");
    } finally {
      setIsSaving(false);
    }
  };

  // Save Basic Info section
  const saveBasicInfo = async () => {
    if (!property?.id) return;

    try {
      setIsSavingBasic(true);

      // Get only basic info fields
      const basicInfoData = {
        name: watch("name"),
        property_type: watch("property_type"),
        bedrooms: watch("bedrooms"),
        bathrooms: watch("bathrooms"),
        max_occupancy: watch("max_occupancy"),
        address: watch("address"),
        city: watch("city"),
        state: watch("state"),
        zip: watch("zip"),
        country: watch("country"),
        description: watch("description"),
      };

      await updateProperty(property.id, basicInfoData);
      toast.success("Basic property info saved");
    } catch (error) {
      console.error("Error saving basic info:", error);
      toast.error("Failed to save basic info");
    } finally {
      setIsSavingBasic(false);
    }
  };

  // Save Property Details section
  const savePropertyDetails = async () => {
    if (!user || !property?.id) return;

    try {
      setIsSavingDetails(true);

      // Get only property details fields
      const detailsData = {
        wifi_name: watch("wifi_name"),
        wifi_password: watch("wifi_password"),
        check_in_instructions: watch("check_in_instructions"),
        check_out_instructions: watch("check_out_instructions"),
        house_rules: watch("house_rules"),
        security_info: watch("security_info"),
        parking_info: watch("parking_info"),
        amenities: watch("amenities"),
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from("properties")
        .update(detailsData)
        .eq("id", property.id);

      if (error) throw error;

      toast.success("Property details saved");
    } catch (error: any) {
      console.error("Error saving property details:", error);
      toast.error(error.message || "Failed to save property details");
    } finally {
      setIsSavingDetails(false);
    }
  };

  // Save Location section
  const saveLocation = async () => {
    if (!user || !property?.id) return;

    try {
      setIsSavingLocation(true);

      // Get only location fields
      const locationData = {
        latitude: watch("latitude"),
        longitude: watch("longitude"),
        neighborhood_description: watch("neighborhood_description"),
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from("properties")
        .update(locationData)
        .eq("id", property.id);

      if (error) throw error;

      toast.success("Location information saved");
    } catch (error: any) {
      console.error("Error saving location info:", error);
      toast.error(error.message || "Failed to save location info");
    } finally {
      setIsSavingLocation(false);
    }
  };

  // Handle main photo upload
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type and size
    if (!file.type.match(/image\/(jpeg|jpg|png|webp)/i)) {
      toast.error("Please select a valid image file (JPEG, PNG, WEBP)");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      // 10MB limit
      toast.error("Image must be less than 10MB");
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // Create unique filename
      const fileExt = file.name.split(".").pop();
      const fileName = `property-${Date.now()}.${fileExt}`;
      const filePath = `properties/${fileName}`;

      // Set up a progress tracker using XMLHttpRequest
      const xhr = new XMLHttpRequest();
      xhr.upload.addEventListener("progress", (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          setUploadProgress(percent);
        }
      });

      // Upload to Supabase Storage using standard options
      const { error: uploadError } = await supabase.storage
        .from("properties")
        .upload(filePath, file, {
          cacheControl: "31536000", // 1 year for static images
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from("properties").getPublicUrl(filePath);

      if (!property?.id) {
        toast.error("Please save basic property information first");
        return;
      }

      // Update property record
      const { error: updateError } = await supabase
        .from("properties")
        .update({ main_photo_url: publicUrl })
        .eq("id", property.id);

      if (updateError) throw updateError;

      // Update local state
      setProperty({
        ...property,
        main_photo_url: publicUrl,
      });

      // Now this will work because we added main_photo_url to the interface
      setValue("main_photo_url", publicUrl);
      toast.success("Property image updated!");
    } catch (error: any) {
      console.error("Error uploading image:", error);
      toast.error(error.message || "Failed to upload image");
    } finally {
      setIsUploading(false);
    }
  };

  // Tab classnames helper
  function classNames(...classes: string[]) {
    return classes.filter(Boolean).join(" ");
  }

  return (
    <AuthenticatedLayout>
      <PermissionGate
        requiredRole="manager"
        fallback={
          <div className="p-8 text-center">
            Access restricted to property managers and owners.
          </div>
        }
      >
        <div className="container mx-auto py-8 px-4">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Property Settings</h1>
            <button
              onClick={handleSubmit(onSubmit)}
              disabled={isSaving}
              className={`
                flex items-center px-4 py-2 rounded-md shadow-sm
                ${isSaving ? "bg-gray-400" : "bg-blue-600 hover:bg-blue-700"}
                text-white font-medium text-sm
              `}
            >
              {isSaving ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Saving...
                </span>
              ) : (
                <span className="flex items-center">
                  <Save className="h-4 w-4 mr-2" />
                  Save All Settings
                </span>
              )}
            </button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-16">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <form>
              <Tab.Group
                selectedIndex={selectedTabIndex}
                onChange={setSelectedTabIndex}
              >
                <Tab.List className="flex space-x-1 rounded-xl bg-blue-600 p-1 mb-8">
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                        "ring-white ring-opacity-60 focus:outline-none transition-all",
                        selected
                          ? "bg-white text-blue-700 shadow"
                          : "text-white hover:bg-blue-700/80"
                      )
                    }
                  >
                    <div className="flex items-center justify-center">
                      <Building2 className="h-4 w-4 mr-2" />
                      Basic Info
                    </div>
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                        "ring-white ring-opacity-60 focus:outline-none transition-all",
                        selected
                          ? "bg-white text-blue-700 shadow"
                          : "text-white hover:bg-blue-700/80"
                      )
                    }
                  >
                    <div className="flex items-center justify-center">
                      <Upload className="h-4 w-4 mr-2" />
                      Visual Assets
                    </div>
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                        "ring-white ring-opacity-60 focus:outline-none transition-all",
                        selected
                          ? "bg-white text-blue-700 shadow"
                          : "text-white hover:bg-blue-700/80"
                      )
                    }
                  >
                    <div className="flex items-center justify-center">
                      <Info className="h-4 w-4 mr-2" />
                      Property Details
                    </div>
                  </Tab>
                  <Tab
                    className={({ selected }) =>
                      classNames(
                        "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                        "ring-white ring-opacity-60 focus:outline-none transition-all",
                        selected
                          ? "bg-white text-blue-700 shadow"
                          : "text-white hover:bg-blue-700/80"
                      )
                    }
                  >
                    <div className="flex items-center justify-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      Location
                    </div>
                  </Tab>
                </Tab.List>

                <Tab.Panels className="mt-2">
                  {/* Basic Property Information */}
                  <Tab.Panel className="rounded-xl bg-white p-6 shadow">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="col-span-1 md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Property Name
                        </label>
                        <input
                          type="text"
                          {...register("name", {
                            required: "Property name is required",
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                        {errors.name && (
                          <p className="mt-1 text-sm text-red-600">
                            {errors.name.message}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Property Type
                        </label>
                        <select
                          {...register("property_type")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="">Select property type...</option>
                          {propertyTypes.map((type) => (
                            <option key={type} value={type.toLowerCase()}>
                              {type}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Bedrooms
                          </label>
                          <input
                            type="number"
                            {...register("bedrooms", { min: 0 })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Bathrooms
                          </label>
                          <input
                            type="number"
                            step="0.5"
                            {...register("bathrooms", { min: 0 })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Max Occupancy
                          </label>
                          <input
                            type="number"
                            {...register("max_occupancy", { min: 1 })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                      </div>

                      <div className="col-span-1 md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Address
                        </label>
                        <input
                          type="text"
                          {...register("address")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          City
                        </label>
                        <input
                          type="text"
                          {...register("city")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            State/Province
                          </label>
                          <input
                            type="text"
                            {...register("state")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            ZIP/Postal Code
                          </label>
                          <input
                            type="text"
                            {...register("zip")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Country
                        </label>
                        <input
                          type="text"
                          {...register("country")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>

                      <div className="col-span-1 md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea
                          {...register("description")}
                          rows={4}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Short description of your property..."
                        ></textarea>
                      </div>
                    </div>
                    <div className="flex justify-end mt-4">
                      <button
                        onClick={saveBasicInfo}
                        disabled={isSavingBasic}
                        className={`
                          flex items-center px-4 py-2 rounded-md shadow-sm
                          ${isSavingBasic ? "bg-gray-400" : "bg-blue-600 hover:bg-blue-700"}
                          text-white font-medium text-sm
                        `}
                      >
                        {isSavingBasic ? (
                          <span className="flex items-center">
                            <svg
                              className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 7.962 
